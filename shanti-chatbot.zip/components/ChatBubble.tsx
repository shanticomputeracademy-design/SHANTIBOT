
import React from 'react';
import { Message } from '../types';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isModel = message.role === 'model';

  return (
    <div className={`flex w-full mb-6 ${isModel ? 'justify-start' : 'justify-end animate-in fade-in slide-in-from-bottom-2'}`}>
      <div className={`max-w-[80%] px-4 py-3 rounded-2xl shadow-sm ${
        isModel 
          ? 'bg-white text-gray-800 border border-gray-100 rounded-tl-none' 
          : 'bg-indigo-600 text-white rounded-tr-none'
      }`}>
        <p className="whitespace-pre-wrap leading-relaxed">
          {message.text}
        </p>
        <div className={`text-[10px] mt-2 opacity-60 ${isModel ? 'text-gray-500' : 'text-indigo-100'}`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
};

export default ChatBubble;
