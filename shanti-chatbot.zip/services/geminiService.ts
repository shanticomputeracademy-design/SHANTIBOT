
import { GoogleGenAI, Type, FunctionDeclaration, GenerateContentResponse } from "@google/genai";
import { getStudentResult } from "./studentService";

const API_KEY = process.env.API_KEY || "";

const studentResultFunctionDeclaration: FunctionDeclaration = {
  name: 'getStudentResult',
  parameters: {
    type: Type.OBJECT,
    description: 'Fetch the last test result for a student based on their unique Student ID.',
    properties: {
      studentId: {
        type: Type.STRING,
        description: 'The unique ID of the student (e.g., S101, S102).',
      },
    },
    required: ['studentId'],
  },
};

export const chatWithShanti = async (
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  userInput: string
) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const modelName = 'gemini-3-flash-preview';

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userInput }] }
      ],
      config: {
        systemInstruction: `Your name is Shanti. You are a helpful, polite, and knowledgeable assistant for a website.
        1. When users ask about computers or how things work, explain them clearly in simple English.
        2. When a user provides a Student ID (e.g., S101) or asks for their "test result", you MUST use the 'getStudentResult' tool.
        3. If the tool returns data, format it nicely for the student (e.g., "Hello [Name], your last test result for [Subject] was [Score] on [Date]").
        4. Always maintain a peaceful and supportive tone (Shanti means Peace).
        5. Greet users in English: "Hi, how can I help you today?"`,
        tools: [{ functionDeclarations: [studentResultFunctionDeclaration] }],
      },
    });

    // Check for function calls
    if (response.candidates?.[0]?.content?.parts) {
      const parts = response.candidates[0].content.parts;
      const functionCall = parts.find(p => p.functionCall);

      if (functionCall) {
        const { name, args, id } = functionCall.functionCall!;
        if (name === 'getStudentResult') {
          const result = await getStudentResult(args.studentId as string);
          
          // Send tool response back to Gemini to get final answer
          const followUp = await ai.models.generateContent({
            model: modelName,
            contents: [
              ...history,
              { role: 'user', parts: [{ text: userInput }] },
              { role: 'model', parts: [functionCall] },
              {
                role: 'user', // In current SDK usage, tool results are often sent back as a simulated user turn or via specialized method if available
                parts: [{ 
                  text: `Tool result for getStudentResult: ${result}` 
                }]
              }
            ],
            config: {
              systemInstruction: `Format the provided student data into a friendly message. If not found, inform them politely.`
            }
          });
          return followUp.text;
        }
      }
    }

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I'm having trouble connecting right now. Please try again later.";
  }
};
