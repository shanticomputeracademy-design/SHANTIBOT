
import { StudentRecord } from '../types';

// Mock database simulating Google Sheets data
const MOCK_STUDENTS: StudentRecord[] = [
  { studentId: "S101", name: "Rahul Kumar", lastTestResult: "85%", subject: "Computer Science", date: "2023-10-15" },
  { studentId: "S102", name: "Anjali Singh", lastTestResult: "92%", subject: "Mathematics", date: "2023-10-12" },
  { studentId: "S103", name: "Amit Patel", lastTestResult: "78%", subject: "Physics", date: "2023-10-14" },
  { studentId: "S104", name: "Priya Sharma", lastTestResult: "95%", subject: "Web Development", date: "2023-10-18" },
];

/**
 * Simulates fetching a student's result from a database.
 * In a real app, this would use the Google Sheets API.
 */
export const getStudentResult = async (studentId: string): Promise<string> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const student = MOCK_STUDENTS.find(s => s.studentId.toUpperCase() === studentId.toUpperCase());
  
  if (student) {
    return JSON.stringify({
      found: true,
      name: student.name,
      score: student.lastTestResult,
      subject: student.subject,
      date: student.date
    });
  }
  
  return JSON.stringify({ 
    found: false, 
    error: `Student ID ${studentId} not found in our records.` 
  });
};
